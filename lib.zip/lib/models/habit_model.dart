class Habit {
  final String id;
  final String title;
  final List<String> completedDates;
  final String? ownerId;

  Habit({
    required this.id,
    required this.title,
    required this.completedDates,
    this.ownerId,
  });

  // ===============================
  // FACTORY FROM FIRESTORE MAP
  // ===============================
  factory Habit.fromMap(Map<String, dynamic> data, String documentId) {
    return Habit(
      id: documentId,
      title: data['title'] as String,
      completedDates: List<String>.from(data['completedDates'] ?? []),
      ownerId: data['ownerId'] as String?,
    );
  }

  // ===============================
  // TO FIRESTORE MAP
  // ===============================
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'completedDates': completedDates,
      'ownerId': ownerId,
    };
  }

  // ===============================
  // COPY WITH
  // ===============================
  Habit copyWith({
    String? id,
    String? title,
    List<String>? completedDates,
    String? ownerId,
  }) {
    return Habit(
      id: id ?? this.id,
      title: title ?? this.title,
      completedDates: completedDates ?? this.completedDates,
      ownerId: ownerId ?? this.ownerId,
    );
  }

  // ===============================
  // HELPER: TODAY (yyyy-MM-dd)
  // ===============================
  String today() {
    final now = DateTime.now();
    return "${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}";
  }

  // ===============================
  // CHECKBOX STATE (AUTO RESET)
  // ===============================
  bool get isDoneToday {
    return completedDates.contains(today());
  }

  // ===============================
  // STREAK CALCULATION
  // ===============================
  int calculateStreak() {
    if (completedDates.isEmpty) return 0;

    final dateSet = completedDates.map((d) => DateTime.parse(d)).toSet();

    int streak = 0;
    DateTime day = DateTime.now();

    while (dateSet.any(
      (d) => d.year == day.year && d.month == day.month && d.day == day.day,
    )) {
      streak++;
      day = day.subtract(const Duration(days: 1));
    }

    return streak;
  }
}
